// pages/demo/index.js
Page({
  data: {
    //功能按钮总宽度
    funBtnsWidth: 130,
    funBtnsWidthShow: 0,
    moveStart: 0,
    moveindex: '',
    msgs: [
      {
        title: "最新消息",
        msgsList: [
          {
            img: 'https://fudezao.oss-cn-qingdao.aliyuncs.com/statics/uper/201909/23/5d882ce3900b7.png',
            ispoint: true,
            msgnumber: 0,
            msgtitle: "优惠促销",
            msgtime: "昨天",
            msgcontent: "消息内容消息内容消息内容消息内容"
          },
          {
            img: 'https://fudezao.oss-cn-qingdao.aliyuncs.com/statics/uper/201909/23/5d882db43842c.png',
            ispoint: true,
            msgnumber: 0,
            msgtitle: "账户通知",
            msgtime: "2019-08-11",
            msgcontent: "您的账户入账 *** 元"
          }
        ]
      },
      {
        title: "两周前的消息",
        msgsList: [
          {
            img: 'https://fudezao.oss-cn-qingdao.aliyuncs.com/statics/uper/201909/23/5d882ce3900b7.png',
            ispoint: true,
            msgnumber: 12,
            msgtitle: "优惠促销",
            msgtime: "昨天",
            msgcontent: "消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容消息内容"
          },
          {
            img: 'https://fudezao.oss-cn-qingdao.aliyuncs.com/statics/uper/201909/23/5d882db43842c.png',
            ispoint: true,
            msgnumber: 0,
            msgtitle: "账户通知",
            msgtime: "2019-08-11",
            msgcontent: "您的账户入账 *** 元"
          }
        ]
      }
    ]
  },
  msgtouchstart: function (e) {
    console.log(e)
    this.setData({
      moveindex: e.currentTarget.dataset.msgindex,
      moveStart: e.changedTouches[0].pageX
    });
  },
  msgtouchend: function (e) {
    if (this.data.funBtnsWidthShow > 0) {
      this.setData({
        funBtnsWidthShow: this.data.funBtnsWidth
      });
    } else {
      this.setData({
        moveindex: '-'
      });
    }
  },
  msgtouchmove: function (e) {
    var moveX = e.changedTouches[0].pageX - this.data.moveStart;
    if (moveX < 0) {
      moveX = moveX * -1;
      if (moveX > this.data.funBtnsWidth) {
        moveX = this.data.funBtnsWidth;
      }
      this.setData({
        funBtnsWidthShow: moveX
      });
    } else {
      this.setData({
        funBtnsWidthShow: 0
      });
    }
  },
  removemsg: function (e) {
    var removeindex = e.currentTarget.dataset.remindex;
    removeindex = removeindex.split(',');
    wx.showModal({
      title: '提示',
      content: '确定删除消息吗?',
      success: (res) => {
        if (res.confirm) {
          this.data.msgs[removeindex[0]].msgsList.splice(removeindex[1], 1);
          this.moveindex = '-';
          // 如果当前消息组已经没有消息则删除整个组
          if (this.data.msgs[removeindex[0]].msgsList.length < 1) {
            this.data.msgs.splice(removeindex[0], 1);
          }
          // 如果消息为空
          if (this.data.msgs.length < 1) { this.data.msgs = []; }
          this.setData({
            msgs: this.data.msgs,
            moveindex: '-'
          });
        }
      }
    });
  },
  readedmsg: function (e) {
    var index = e.currentTarget.dataset.readindex;
    index = index.split(',');
    this.data.msgs[index[0]].msgsList[index[1]].msgnumber = 0;
    this.setData({
      msgs: this.data.msgs,
      moveindex: '-'
    });
  },
  gotoinfo:function(){
    wx.navigateTo({
      url: '../info/info',
    })
  }
})