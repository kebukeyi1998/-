<template>
	<gracePage statusBarBG="rgba(255,255,255,0)" :headerHeight="0">
		<view slot="gBody">
			<view class="help-bg"></view>
			<view class="help-body">
				<view><text class="grace-h3 grace-white">帮助中心</text></view>
				<view class="grace-grids grace-flex-center grace-box-shadow" style="margin-top:50rpx;">
					<view class="grace-grids-items">
						<text class="grace-grids-icon grace-icons icon-help1 grace-green"></text>
						<text class="grace-grids-text">立即提问</text>
					</view>
					<view class="grace-grids-items">
						<text class="grace-grids-icon grace-icons icon-tel grace-blue"></text>
						<text class="grace-grids-text">电话客服</text>
					</view>
					<view class="grace-grids-items">
						<text class="grace-grids-icon grace-icons icon-article grace-yellow"></text>
						<text class="grace-grids-text">我的问题</text>
					</view>
					<view class="grace-grids-items">
						<text class="grace-grids-icon grace-icons icon-kf1 grace-red"></text>
						<text class="grace-grids-text">在线客服</text>
					</view>
				</view>
				<view class="grace-list" style="margin-top:50rpx;">
					<view class="grace-list-items">
						<view class="grace-list-body grace-border-b">
							<view class="grace-list-title">
								<text class="grace-list-title-text">上课时突然看不见怎么办？</text>
							</view>
						</view>
						<text class="grace-list-arrow-right grace-icons icon-arrow-right"></text>
					</view>
					<view class="grace-list-items">
						<view class="grace-list-body grace-border-b">
							<view class="grace-list-title">
								<text class="grace-list-title-text">为什么摄像头和麦克风在检测时正常，上课却出问题为什么摄像头和麦克风在检测时正常，上课却出问题？</text>
							</view>
						</view>
						<text class="grace-list-arrow-right grace-icons icon-arrow-right"></text>
					</view>
					<view class="grace-list-items">
						<view class="grace-list-body grace-border-b">
							<view class="grace-list-title">
								<text class="grace-list-title-text">上课时候视频播放很卡怎么办？</text>
							</view>
						</view>
						<text class="grace-list-arrow-right grace-icons icon-arrow-right"></text>
					</view>
					<view class="grace-list-items">
						<view class="grace-list-body grace-border-b">
							<view class="grace-list-title">
								<text class="grace-list-title-text">提示银行卡信息错误怎么办？</text>
							</view>
						</view>
						<text class="grace-list-arrow-right grace-icons icon-arrow-right"></text>
					</view>
					<view class="grace-list-items">
						<view class="grace-list-body">
							<view class="grace-list-title">
								<text class="grace-list-title-text">能不能分期支付？</text>
							</view>
						</view>
						<text class="grace-list-arrow-right grace-icons icon-arrow-right"></text>
					</view>
				</view>
			</view>
		</view>
	</gracePage>
</template>
<script>
import gracePage from "../../graceUI/components/gracePage.vue";
export default{
	data() {
		return {}
	},
	components:{gracePage}
}
</script>
<style>
page{background-color:#F6F7F8;}
.help-bg{height:350rpx; background:linear-gradient(to top,#36DBC6,#1FD395); border-radius:0 0 50rpx 50rpx;}
.help-body{width:680rpx; left:35rpx; top:150rpx; position:absolute; z-index:1;}
.grace-grids{background-color:#FFFFFF; border-radius:20rpx; padding:10rpx 0;}
.grace-grids-items{width:160rpx;}
</style>