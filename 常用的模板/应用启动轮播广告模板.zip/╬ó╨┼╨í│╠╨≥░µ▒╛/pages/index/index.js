Page({
  data: {
    
  },
  onLoad: function () {
    // 实际开发时根据本地记录或者 api 记录决定是否打开广告页面
    wx.navigateTo({
      url: "../banner/banner"
    })
  }
})