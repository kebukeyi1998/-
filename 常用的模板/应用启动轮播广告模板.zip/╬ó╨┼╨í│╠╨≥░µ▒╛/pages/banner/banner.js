// pages/banner/banner.js
var graceSysInfo = require('../../graceUI/jsTools/systemInfo.js');
Page({
  data: {
    startBannerHeight: 500
  },
  onLoad: function () {
    var system = graceSysInfo.info();
    this.setData({startBannerHeight : system.windowHeight});
  },
  closeStartBanner: function () {
    wx.navigateBack();
  }
})