<template>
	<gracePage :customHeader="false">
		<view slot="gBody">
			<!-- 页面主体根据项目真实需求 自行编写 -->
		</view>
	</gracePage>
</template>
<script>
import gracePage from "../../graceUI/components/gracePage.vue";
export default{
	data() {
		return {
		}
	},
	components:{
		gracePage
	},
	onLoad:function(){
		// 实际开发时根据本地记录或者 api 记录决定是否打开广告页面
		uni.navigateTo({
			url:"../banner/banner"
		})
	}
}
</script>
<style>
</style>