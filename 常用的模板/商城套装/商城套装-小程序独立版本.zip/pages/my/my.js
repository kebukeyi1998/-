Page({
  data: {
    items: [
      [80, '', '动态'],
      [100, '', '好友'],
      [50, '', '私信'],
      ['￥199', '', '余额']
    ]
  },
  gotoMyOrder : function(){
    wx.navigateTo({
      url: '../myorders/myorders',
    })
  }
})