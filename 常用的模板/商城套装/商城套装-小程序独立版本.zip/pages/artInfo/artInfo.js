Page({
  data: {
    graceSkeleton: true,
    //文章对象格式
    //{
    //	title : "标题",
    //	authorFcae : "作者头像",
    //	authorName : "作者姓名",
    //	viewNumber : "浏览次数",
    //	date       : "日期",
    //	contents   : [
    //		{type : "text", content : "文本内容"},
    //		{type : "img", content : "图片路径"},
    //		//.....
    //	]
    //}
    article: {}
  },
  onLoad: function () {
    // 加载文章详情
    wx.showLoading({});
    wx.request({
      url: 'http://grace.hcoder.net/api/news/info',
      method: 'GET',
      data: {},
      success: (res) => {
        console.log(res)
        var news = res.data.data;
        wx.setNavigationBarTitle({ title: news.title });
        // 此处先规划骨架
        var art = { contents: [] };
        for (var i = 0; i < news.contents.length; i++) {
          art.contents.push({ 'type': news.contents[i].type });
        }
        this.setData({ article: art });
        // 骨架屏规划后延长 500 毫秒进行数据替换
        setTimeout(() => {
          this.setData({ article: news, graceSkeleton: false });
        }, 500);
      },
      fail: () => { },
      complete: () => {
        wx.hideLoading();
      }
    });
  },
  prevImg: function (e) {
    var imgs = [];
    var currentUrl = e.currentTarget.dataset.imgurl;
    for (let i = 0; i < this.data.article.contents.length; i++) {
      if (this.data.article.contents[i].type == 'img') {
        imgs.push(this.data.article.contents[i].content);
      }
    }
    wx.previewImage({
      urls: imgs,
      current: currentUrl
    })
  }
})