//index.js
Page({
  data: {
    swiperItems: [],
    indexCate: [],
    youlikes: [],
    indexCateAndProducts: [],
    top: 0
  },
  onLoad: function () {
    // 加载轮播
    wx.request({
      url : 'http://grace.hcoder.net/api/swipers',
      success: (res) => { this.setData({ swiperItems: res.data.data });}
    });
    // 加载首页推荐图标
    wx.request({
      url : 'http://grace.hcoder.net/api/cate/indexCate',
      success : (res) => { this.setData({ indexCate: res.data.data });}
    });
    // 猜你喜欢
    this.youlike();
    // 加载首页推荐分类及产品
    wx.request({
      url : 'http://grace.hcoder.net/api/products/indexTj',
      success: (res) => {this.setData({ indexCateAndProducts: res.data.data});}
    });
  },
  // 搜索相关函数
  inputting: function (e) { console.log(e); },
  confirm: function (e) { console.log(e); },
  // 猜你喜欢
  youlike: function () {
    wx.request({
      url : 'http://grace.hcoder.net/api/products/youlike',
      success : (res) => { this.setData({ youlikes: res.data.data }); }
    });
  },
  // 打开商品详情
  openProductInfo: function (e) {
    console.log(e)
    wx.navigateTo({ url: '../productInfo/productInfo' });
  }
})
