var systemInfo = require('../../graceUI/jsTools/systemInfo.js');
var request = require('../../graceUI/jsTools/request.js');
Page({
  onReady: function () {
    setTimeout(() => {
      wx.createSelectorQuery().select('#gBody').fields({ size: true }, (res) => {
        wx.createSelectorQuery().select('#nav').fields({ size: true }, (res2) => {
          this.setData({ mainHeight: res.height - res2.height });
        }).exec();
      }).exec();
    }, 1000);
  },
  data: {
    mainHeight: 500,
    swiperCurrentIndex: 0,
    tabs: ['全部', '待付款', '待收货', '已完成', '已取消'],
    tabHeight: 200,
    // 订单数据  订单数组和订单状态数组元素一致
    orders: [[], [], [], [], []],
    // 订单页码
    pages: [1, 1, 1, 1, 1],
    // 加载状态
    loadingTypes: [3, 3, 3, 3, 3]
  },
  onLoad: function () {
    var system = systemInfo.info();
    this.setData({ tabHeight: system.windowHeight - system.iphonexbottomheightpx - (system.rpx2px * 110) });
    this.getOrders();
  },
  navChange: function (e) {
    this.setData({ swiperCurrentIndex: e.detail });
  },
  swiperChange: function (e) {
    var index = e.detail.current;
    this.setData({ swiperCurrentIndex: index });
    // 如果切换时尚未读取数据则读取
    if (this.data.orders[this.data.swiperCurrentIndex].length < 1 && this.data.loadingTypes[this.swiperCurrentIndex] != 5) {
      this.getOrders();
    }
  },
  scrollend: function () {
    // 避免重复加载
    if (this.data.loadingTypes[this.swiperCurrentIndex] == 1 || this.data.loadingTypes[this.swiperCurrentIndex] == 2) { return; }
    this.getOrders();
  },
  getOrders: function () {
    console.log('类型 : ' + this.data.tabs[this.data.swiperCurrentIndex] + ' 第' + this.data.pages[this.data.swiperCurrentIndex] + '页');
    this.data.loadingTypes.splice(this.swiperCurrentIndex, 1, 1);
    this.setData({ loadingTypes: this.data.loadingTypes });
    // this.tabs[this.swiperCurrentIndex] 代表向 api 接口传递订单要求返回的订单状态
    // page 代表第几页
    // 接口地址组合
    var url = "http://grace.hcoder.net/api/index/orders/" + this.data.tabs[this.data.swiperCurrentIndex] + '/' + this.data.pages[this.data.swiperCurrentIndex];
    request.get(url, {}, res => {
      console.log(res)
      if (res.status == 'ok') {
        // 第一页
        if (this.data.pages[this.data.swiperCurrentIndex] == 1) {
          this.data.orders.splice(this.data.swiperCurrentIndex, 1, res.data);
          this.setData({ orders: this.data.orders });
        }
        // 之后的加载页
        else {
          this.data.orders[this.data.swiperCurrentIndex] = this.data.orders[this.data.swiperCurrentIndex].concat(res.data);
          this.setData({ orders: this.data.orders });
        }
        // 页码增加
        this.data.pages[this.data.swiperCurrentIndex]++;
        this.setData({ pages: this.data.pages });
        this.data.loadingTypes.splice(this.data.swiperCurrentIndex, 1, 3);
        this.setData({ loadingTypes: this.data.loadingTypes });
      } else if (res.status == 'empty') {
        console.log('empty');
        this.data.loadingTypes.splice(this.data.swiperCurrentIndex, 1, 5);
        this.setData({ loadingTypes: this.data.loadingTypes });
      } else if (res.status == 'nomore') {
        console.log('nomore');
        this.data.loadingTypes.splice(this.swiperCurrentIndex, 1, 2);
        this.setData({ loadingTypes: this.data.loadingTypes });
      }
    });
  },
  removeorder: function (oid) {
    console.log(oid);
    uni.showModal({
      title: '确认提醒',
      content: '您确定要移除订单 [ ' + oid + ' ] 吗？',
      success: function (e) {
        if (e.confirm) {
          //自行完善删除代码
        }
      }
    });
  }
})