<template>
	<gracePage :customHeader="false">
		<view slot="gBody" class="grace-body">
			<!-- 收货地址 -->
			<view class="grace-list grace-margin-top grace-bg-white grace-border-radius-small" style="padding:10rpx 20rpx;">
				<navigator class="grace-list-items">
					<view class="grace-list-body">
						<view class="grace-list-title">
							<text class="grace-list-title-text address">陕西省西安市科技二路1005号</text>
						</view>
						<view class="grace-list-body-desc">GraceUI 180****5598</view>
					</view>
					<text class="grace-list-arrow-right grace-icons icon-arrow-right"></text>
				</navigator>
			</view>
			<!-- 商品信息 -->
			<view class="grace-shoppingcard grace-margin-top" v-for="(item, index) in shoppingCard" :key="index">
				<view class="grace-shopp-name">
					<text class="grace-h5 grace-bold">{{item.shopName}}</text>
				</view>
				<view style="height:25rpx;"></view>
				<view class="grace-shoppingcard-goods" v-for="(goods, indexItem) in item.items" :key="indexItem">
					<image :src="goods.img" class="grace-shoppingcard-goods-image" mode="widthFix"></image>
					<view class="grace-shoppingcard-goods-body">
						<view class="grace-shoppingcard-goods-title">{{goods.goodsName}}</view>
						<view class="grace-space-between">
							<text class="grace-shoppingcard-goods-price">￥{{goods.price}}</text>
							<text>X {{goods.count}}</text>
						</view>
					</view>
				</view>
			</view>
		</view>
	</gracePage>
</template>
<script>
import gracePage from "../../graceUI/components/gracePage.vue";
export default {
	data() {
		return {
			shoppingCard : [
			{
				"checked" : true,
				"shopName": "hcoder 官方店",
				"shopId": "1",
				"items": [
					{
						"goodsId": 1,
						"goodsName": "hcoder 演示商品",
						"price": 10.00,
						"count": 1,
						"img": "https://m.360buyimg.com/babel/jfs/t1/3730/7/3438/394579/5b996f2eE1727c59e/373cf10d42a53b72.jpg",
						"checked" : true
					},
					{
						"goodsId": 2,
						"goodsName": "dcloud 演示商品",
						"price": 20.00,
						"count": 1,
						"img": "https://img14.360buyimg.com/n7/jfs/t1/1156/8/14017/123589/5bd9a4e8E7dbd4a15/70fbbccdf8811111.jpg",
						"checked" : true
					}
				]
			},
			{
				"checked" : true,
				"shopName": "grace 官方旗舰店",
				"shopId": "2",
				"items": [
					{
						"goodsId": 3,
						"goodsName": "uni-app 演示商品",
						"price": 30.00,
						"count": 2,
						"img": "https://img10.360buyimg.com/n7/jfs/t19690/263/1947634738/190301/ad172397/5adfe5eaN42591f8c.jpg",
						"checked" : true
					}
				]
			}]
		}
	},
	methods: {
		
	},
	components:{
		gracePage
	}
}
</script>
<style>
page{background-color:#F8F8F8;}
.address{font-size:32rpx !important; line-height:60rpx;}

.grace-shoppingcard{background:#FFFFFF; border-radius:8rpx; padding:20rpx; margin-bottom:20rpx;}
.grace-shopp-name{width:500rpx;}
.grace-shopp-go{width:120rpx;}
.grace-shoppingcard-goods{margin:15rpx 0; display:flex; flex-wrap:nowrap;}
.grace-shoppingcard-goods-checkbtn{width:60rpx; flex-shrink:0;}
.grace-shoppingcard-goods-image{width:120rpx; margin-right:20rpx; flex-shrink:0;}
.grace-shoppingcard-goods-body{width:100%;}
.grace-shoppingcard-goods-title{line-height:2em;}
.grace-shoppingcard-goods-price{color:#F00; font-size:28rpx; display:flex; flex-wrap:nowrap; justify-content:space-between;}
.grace-shoppingcard-goods-number{padding:2px 0;}
.grace-shoppingcard-remove{display:block; text-align:right; line-height:50rpx; margin-top:30rpx; color:#CCCCCC; font-size:24rpx;}
.grace-shoppingcard-checkbtn{width:200rpx; margin-left:50rpx; flex-shrink:0;}
.grace-shoppingcard-count{width:600rpx;}
.grace-shoppingcard-checkout{width:280rpx; height:100rpx; line-height:100rpx; font-size:28rpx; text-align:center; flex-shrink:0;}
</style>