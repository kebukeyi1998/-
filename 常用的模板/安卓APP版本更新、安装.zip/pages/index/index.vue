<template>
	<view class="grace-body">
		<view class="grace-title">安卓端 APP 版本检查及更新安卓示例</view>
		<view class="grace-text">
			首页检查版本更新，具体内容请根据项目需求自行编写 ^_^
		</view>
	</view>
</template>
<script>
export default{
	data() {
		return {}
	},
	onLoad:function(){
		// 设置 app 当前版本
		var version = '1.0.1';
		// 版本检查
		uni.request({
			url:'http://grace.hcoder.net/api/index/version',
			success:(res)=>{
				console.log(res);
				if(version != res.data.version){
					uni.navigateTo({
						url:'../update/update',
					})
				}
			}
		})
	}
}
</script>
<style>
</style>