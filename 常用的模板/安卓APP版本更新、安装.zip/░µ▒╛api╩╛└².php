<?php
$version = array(
	'version' => '1.1.2',
	'apkurl'  => 'http://img.cdn.aliyun.dcloud.net.cn/guide/uniapp/HelloUniApp@v2.3.7.apk',
	'desc'     => "1.1.2 版本优化项目 : 
1. 优化新闻列表
2. 新增好友功能
3. 解决某某 BUG");
echo json_encode($version);