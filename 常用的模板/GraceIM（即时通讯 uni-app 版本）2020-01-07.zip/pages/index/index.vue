<template>
	<gracePage :customHeader="false">
		<!-- 页面主体 -->
		<view slot="gBody" class="grace-body">
			<!-- 消息列表 滑动列表 -->
			<view class="grace-title grace-margin-top">消息列表</view>
			<view class="grace-list">
				<navigator :url="'../chat/chat?group='+item.group" class="grace-list-items" v-for="(item, index) in graceIMFriends" :key="index">
					<view class="grace-list-image grace-relative">
						<image class="grace-list-image" :src="item.face" mode="widthFix"></image>
					</view>
					<view 
					class="grace-list-body" :data-msgindex="index" 
					@touchstart="msgtouchstart" @touchend="msgtouchend" @touchmove="msgtouchmove">
						<view class="grace-list-title">
							<text class="grace-list-title-text">{{item.name}}</text>
							<text class="grace-list-title-desc">{{item.lastdate}}</text>
						</view>
						<view class="grace-list-body-desc grace-ellipsis">
							{{item.lastcontent}}
						</view>
					</view>
					<view class="grace-fun-btn" :style="{width:funBtnsWidthShow+'px'}" v-if="moveindex == index">
						<text class="grace-fun-btns" @tap.stop="removemsg" :data-remindex="index">删除</text>
					</view>
				</navigator>
			</view>
			<!-- 消息列表 滑动列表 -->
			<view class="grace-title grace-margin-top">推荐群 ( 点击加入 )</view>
			<view class="grace-list">
				<navigator class="grace-list-items" url="../chat/chat?group=group1">
					<view class="grace-list-image grace-relative">
						<image class="grace-list-image" src="https://graceui.oss-cn-beijing.aliyuncs.com/logo.png" mode="widthFix"></image>
					</view>
					<view class="grace-list-body">
						<view class="grace-list-title">
							<text class="grace-list-title-text">GraceUI 交流群</text>
						</view>
						<view class="grace-list-body-desc">GraceUI 官方交流群, 点击加入</view>
					</view>
					<view class="arrow-right"></view>
				</navigator>
				<navigator class="grace-list-items" url="../chat/chat?group=group2">
					<view class="grace-list-image grace-relative">
						<image class="grace-list-image" src="https://graceui.oss-cn-beijing.aliyuncs.com/h.png" mode="widthFix"></image>
					</view>
					<view class="grace-list-body">
						<view class="grace-list-title">
							<text class="grace-list-title-text">Hcoder 交流群</text>
						</view>
						<view class="grace-list-body-desc">Hcoder 官方交流群, 点击加入</view>
					</view>
					<view class="arrow-right"></view>
				</navigator>
			</view>
		</view>
	</gracePage>
</template>
<script>
import gracePage from "../../graceUI/components/gracePage.vue";
var graceRandom = require("../../graceUI/jsTools/random.js");
var randStr     = graceRandom.uuid(10);
// 挂载 vuex
import {mapState, mapMutations} from 'vuex';
export default {
	data() {
		return {
			//功能按钮总宽度
			funBtnsWidth : 100,
			funBtnsWidthShow : 0,
			moveStart  : 0,
			moveindex : ''
		}
	},
	computed: {
		...mapState(['graceIMFriends'])
	},
	onLoad : function(){
		/* 模拟一个用户信息 实际项目开发用户信息来自您的项目登录 */
		try{
			var user = uni.getStorageSync('suser');
			if(!user){
				var randStr     = graceRandom.uuid(10);
				user  = {
					uindex    : randStr,	// 用户索引 ( 需要保证全局的唯一性 )
					uname     : '用户 ' + randStr, // 用户称呼
					uface     : 'https://graceui.oss-cn-beijing.aliyuncs.com/faces/1.png', // 头像
					utype     : 'formal', // 用户类型 [formal : 正式的，会记录到数据库 、 temporary : 临时的]
				};
				// 将用户信息保存在本地
				uni.setStorageSync('suser', JSON.stringify(user));
			}else{
				user = JSON.parse(user);
			}
			this.graceIMConnect(user);
		}catch(e){
			//TODO handle the exception
		}
	},
	onShow:function(){
		this.getFriendList();
	},
	methods:{
		...mapMutations(['graceIMRegGroup', 'graceIMConnect', 'getFriendList']),
		msgtouchstart : function(e){
			this.moveindex = e.currentTarget.dataset.msgindex;
			this.moveStart = e.changedTouches[0].pageX;
		},
		msgtouchend : function(e){
			if(this.funBtnsWidthShow > 0){
				this.funBtnsWidthShow = this.funBtnsWidth;
			}else{
				this.moveindex = '-';
			}
		},
		msgtouchmove : function(e){
			var moveX = e.changedTouches[0].pageX - this.moveStart;
			if(moveX < 0){
				moveX = moveX * -1;
				if(moveX > this.funBtnsWidth){
					moveX = this.funBtnsWidth;
				}
				this.funBtnsWidthShow = moveX;
			}else{
				this.funBtnsWidthShow = 0;
			}
		},
		removemsg : function (e) {
			var removeindex = e.currentTarget.dataset.remindex;
			uni.showModal({
				title: '提示',
				content: '确定删除消息吗?',
				success: (res)  => {
					if (res.confirm) {
						this.graceIMFriends.splice(removeindex,1);
						this.moveindex = '-';
					}
				}
			});
		}
	},
	components:{gracePage}
}
</script>
<style>
.grace-body{padding:15rpx 25rpx;}
.grace-list-body-desc{line-height:40rpx; height:40rpx;}
.grace-fun-btn{width:100rpx; display:flex; flex-direction:row; flex-wrap:nowrap; margin-left:20rpx;}
.grace-fun-btns{display:block; width:150px; text-align:center; line-height:110rpx; background-color:#FF0036; color:#FFFFFF; font-size:28rpx; height:110rpx; overflow:hidden;}
</style>