<script>
export default {
	onLaunch : function(){
		
	}
}
</script>
<style>
@import "./graceUI/graceIcons.css";
@import "./graceUI/graceUI.css";
navigator{opacity:1; background:none;}
.navigator-hover{background:none; opacity:0.8;}
</style>